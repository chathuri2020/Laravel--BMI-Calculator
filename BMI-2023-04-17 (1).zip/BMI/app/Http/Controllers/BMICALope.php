<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BMICALope extends Controller
{
    //
    public function CalFemale(Request $request)
    {
        //
        $weight = $request->Weight; // $POST_['Weight']
        $height  = $request->Height;
        $Hunits = $request->H_units;
        if ($Hunits === 'Meters') {
            $height  = $height;
        } elseif ($Hunits === 'Feets') {
            $height  = $height / 3.28;
        } elseif ($Hunits === 'Inches') {
            $height  = $height *  0.0254;
        }
        $FBMI = $weight / ($height * $height);
        //  return view('welcome');
        return view('welcome', compact('FBMI'));
    }

    public function CalMale(Request $request)
    {
        //
        $weight = $request->Weight;
        $height  = $request->Height;

        //  return view('welcome');
        $Hunits = $request->H_units;
        if ($Hunits === 'Meters') {
            $height  = $height;
        } elseif ($Hunits === 'Feets') {
            $height  = $height / 3.28;
        } elseif ($Hunits === 'Inches') {
            $height  = $height *  0.0254;
        }


        $MBMI = $weight / ($height * $height);
        return view('welcome', compact('MBMI'));
    }

    /*
       <?php
    $weight = $_POST['Weight'];
    $height = $_POST['Height'];
    $BMI = $weight / $height * $height;
    echo $BMI;
    ?>


    feet / 3.28  = meters



    */
}
