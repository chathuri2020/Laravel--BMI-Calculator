<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BMI Calculator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <style>
            .display {
                width: 100%;
                height: 30%;
                background-color: rgb(196, 204, 255);
                padding: 5%;
                color: white;
            }
        </style>
        <br>
        <center>
            <h2>BMI CALCULATOR</h2>
        </center><br><br>
        <div class="row">
            <div class="col-6">
                <center>
                    <h5>Male</h5>
                </center>

                <div class="row">
                    <div class="col-6">
                        <img src="Images/male.jpg" alt="" style="width:200px" height="350px">
                    </div>
                    <div class="col-6">
                        <br>
                        <div class="display">
                            @if(isset($MBMI))
                            <h2>{{$MBMI}}</h2>


                            @if($MBMI < 18.5) <p style="color: red; font-weight:500 ;">Under Weight</p>
                                @elseif($MBMI >= 18.5 && $MBMI <= 24.9 ) <p style="color: green; font-weight:500; ">Normal</p>

                                    @elseif($MBMI >= 25 && $MBMI <= 29.9 ) <p style="color: red; font-weight:500; ">Over Weight</p>

                                        @elseif($MBMI >= 30 && $MBMI <= 34.9 ) <p style="color: red; font-weight:500; ">Obesity (Class I)</p>

                                            @elseif($MBMI >= 35 && $MBMI <= 39.9 ) <p style="color: red;  font-weight:500; ">Obesity (Class II)</p>

                                                @elseif($MBMI > 40 )
                                                <p style="color: red; font-weight:500 ">Extreme Obesity !!! </p>

                                                @endif

                                                @else
                                                <h2>000.00</h2>
                                                @endif

                        </div>
                        <br>
                        <form method="GET" action="{{url('/M')}}">
                            @csrf
                            @method('PUT')
                            <div class="mb-3">
                                <label for="Weight" class="form-label">Weight</label>
                                <input type="text" class="form-control" id="Weight" name="Weight" required>
                                <div id="W" class="form-text">Enter the weight in kilograms</div>
                            </div>
                            <div class="mb-3">
                                <label for="Height" class="form-label">Height</label>
                                <input type="text" class="form-control" id="Height" name="Height" required>
                                <div id="H" class="form-text">Enter the height in meters.</div>
                            </div>

                            <center><button type="submit" class="btn btn-primary" style="background-color: #d34b8f; border:#d63384">Calculate the BMI</button></center>
                        </form>

                    </div>
                </div>
            </div>
            <div class="col-6">
                <center>
                    <h5>Female</h5>
                </center>
                <div class="row">
                    <div class="col-6">
                        <img src="Images/female.jpg" alt="" style="width:210px" height="390px">
                    </div>
                    <div class="col-6">
                        <br>
                        <div class="display">
                            @if(isset($FBMI))
                            <h2>{{$FBMI}}</h2>

                            @if($FBMI < 18.5) <p style="color: red;  font-weight:500;">Under Weight</p>
                                @elseif($FBMI >= 18.5 && $FBMI <= 24.9 ) <p style="color: green;  font-weight:500;">Normal</p>

                                    @elseif($FBMI >= 25 && $FBMI <= 29.9 ) <p style="color: red; font-weight:500;">Over Weight</p>

                                        @elseif($FBMI >= 30 && $FBMI <= 34.9 ) <p style="color: red; font-weight:500;">Obesity (Class I)</p>

                                            @elseif($FBMI >= 35 && $FBMI <= 39.9 ) <p style="color: red; font-weight:500;">Obesity (Class II)</p>

                                                @elseif($FBMI >= 40 )
                                                <p style="color: red; font-weight:500;">Extreme Obesity </p>

                                                @endif
                                                @else
                                                <h2>000.00</h2>
                                                @endif






                        </div>
                        <br>
                        <form method="GET" action="{{url('/F')}}">
                            @csrf
                            @method('PUT')
                            <div class="mb-3">
                                <label for="Weight" class="form-label">Weight</label>
                                <input type="text" class="form-control" id="Weight" name="Weight" required>
                                <div id="W" class="form-text">Enter the weight in kilograms</div>
                            </div>
                            <div class="mb-3">
                                <label for="Height" class="form-label">Height</label>
                                <div class="row">
                                    <div class="col-8">
                                        <input type="text" class="form-control" id="Height" name="Height" required>

                                    </div>
                                    <div class="col-4">
                                      
                                        <select id="Height-u" name="H_units" style="height: 35px; border-color:#dbdbdb;  border-radius:4px;">
                                            <option value="Meters">Meters</option>
                                            <option value="Feets">Feets</option>
                                            <option value="Inches">Inches</option>
                                            
                                        </select>
                                    </div>
                                </div>
                                <div id="H" class="form-text">Enter the height in meters</div>

                            </div>

                            <center><button type="submit" class="btn btn-primary" style="background-color: #d34b8f; border:#d63384">Calculate the BMI</button></center>
                        </form>

                    </div>

                </div>
            </div>
        </div>
    </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html>